import React, { useState, useEffect, useRef } from "react";

// =================================================================
// IDENTIDAD VISUAL — azul marino + beige, acento bronce.
// Nada de plantilla genérica: esquinas rectas, sin sombras difusas,
// sin gradientes. La jerarquía la marca la tipografía y el espaciado,
// no el color.
// =================================================================
const COLORS = {
  bg: "#0c1b2e",        // azul marino profundo, fondo base
  bgPanel: "#12233b",   // panel principal, un tono más cálido que el fondo
  bgPanelAlt: "#1a3151",// panel secundario / citas / inputs
  line: "#2b4360",      // línea divisoria, sutil pero visible
  cream: "#f2e8d5",     // beige cálido — texto principal sobre marino
  creamDim: "#a9b2c2",  // texto secundario, gris-azulado apagado
  gold: "#c3a06a",      // acento bronce — puntuación, CTA, énfasis
  goldDim: "#8f7a52",
  green: "#7fa07c",     // éxito / alta prioridad
  red: "#bd6f5a",       // alerta / descarte
  blue: "#7fa0c4",      // enlaces / información
};
const serif = "'Iowan Old Style', 'Palatino Linotype', Georgia, serif";
const mono = "'IBM Plex Mono', 'Courier New', monospace";

// =================================================================
// UI PRIMITIVES
// =================================================================
function Panel({ children, style }) {
  return <div style={{ background: COLORS.bgPanel, border: `1px solid ${COLORS.line}`, padding: "18px", ...style }}>{children}</div>;
}
function SectionTitle({ children, style }) {
  return <h2 style={{ fontFamily: serif, fontSize: "1.3rem", fontWeight: 500, color: COLORS.cream, margin: "0 0 4px 0", letterSpacing: 0.2, ...style }}>{children}</h2>;
}
function Label({ children }) {
  return <div style={{ fontFamily: mono, fontSize: "0.64rem", color: COLORS.gold, letterSpacing: 1.1, marginBottom: 7, textTransform: "uppercase" }}>{children}</div>;
}
function Badge({ children, color = COLORS.gold }) {
  return <span style={{ fontFamily: mono, fontSize: "0.64rem", color, border: `1px solid ${color}`, padding: "3px 9px", letterSpacing: 0.3 }}>{children}</span>;
}
function TextInput({ value, onChange, placeholder, multiline }) {
  const Tag = multiline ? "textarea" : "input";
  return (
    <Tag value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} rows={multiline ? 3 : undefined}
      style={{ width: "100%", fontFamily: serif, fontSize: "0.92rem", color: COLORS.cream, background: COLORS.bgPanelAlt,
        border: `1px solid ${COLORS.line}`, padding: "11px 13px", outline: "none", resize: multiline ? "vertical" : "none", boxSizing: "border-box" }} />
  );
}
function Chip({ label, active, onClick }) {
  return (
    <button onClick={onClick} style={{ fontFamily: mono, fontSize: "0.72rem", cursor: "pointer", padding: "7px 14px", letterSpacing: 0.2,
      background: active ? COLORS.gold : "transparent", color: active ? COLORS.bg : COLORS.creamDim,
      border: `1px solid ${active ? COLORS.gold : COLORS.line}` }}>{label}</button>
  );
}
function PrimaryButton({ children, onClick, disabled, style }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{ fontFamily: mono, fontSize: "0.78rem", cursor: disabled ? "default" : "pointer", letterSpacing: 0.3,
      background: COLORS.gold, color: COLORS.bg, border: "none", padding: "12px 22px", opacity: disabled ? 0.5 : 1, ...style }}>{children}</button>
  );
}
function GhostButton({ children, onClick, style }) {
  return (
    <button onClick={onClick} style={{ fontFamily: mono, fontSize: "0.7rem", cursor: "pointer", background: "transparent", letterSpacing: 0.2,
      color: COLORS.creamDim, border: `1px solid ${COLORS.line}`, padding: "8px 13px", ...style }}>{children}</button>
  );
}

// =================================================================
// PERSISTENCIA — memoria del propio navegador (localStorage),
// para que la app funcione como una web normal fuera de este chat.
// =================================================================
async function guardar(key, value) {
  try { localStorage.setItem(`radar-comercial:${key}`, JSON.stringify(value)); } catch (e) {}
}
async function cargar(key) {
  try {
    const raw = localStorage.getItem(`radar-comercial:${key}`);
    return raw ? JSON.parse(raw) : null;
  } catch (e) { return null; }
}

// Backend por defecto: el desplegado junto con esta app. Se puede cambiar
// en la pestaña "Fuentes" si algún día usas otro backend.
const BACKEND_URL_PREDETERMINADA = "https://radar-comercial-backend-v2.onrender.com";

// =================================================================
// LLAMADAS AL BACKEND para generar el ICP y analizar el historial de
// ventas. La clave de Anthropic vive SOLO en el backend — nunca en
// el navegador, para que esta web se pueda desplegar en cualquier sitio
// sin exponer ninguna credencial.
// =================================================================
async function llamarBackendJSON(backendUrl, ruta, body) {
  let resp;
  try {
    resp = await fetch(`${backendUrl.replace(/\/$/, "")}${ruta}`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
  } catch (e) {
    throw new Error(`No se pudo conectar con el backend en ${backendUrl}. ¿Está desplegado y accesible? (${e.message})`);
  }
  let data;
  try { data = await resp.json(); } catch (e) { throw new Error("Respuesta inválida del backend."); }
  if (!resp.ok) throw new Error(data.error || `El backend respondió con error ${resp.status}.`);
  return data;
}

async function generarICP(backendUrl, perfil) {
  const data = await llamarBackendJSON(backendUrl, "/api/business/icp", { profile: perfil });
  return data.icp;
}

async function analizarHistorialVentas(backendUrl, textoHistorial, perfil) {
  const data = await llamarBackendJSON(backendUrl, "/api/business/analyze-history", { profile: perfil, historial: textoHistorial });
  return data.analisis;
}

async function inferirNichoSinHistorial(backendUrl, perfil) {
  const data = await llamarBackendJSON(backendUrl, "/api/business/infer-niche", { profile: perfil });
  return data.analisis;
}

// =================================================================
// RADAR AUTÓNOMO — cola persistente en el backend, no búsqueda bajo demanda
// =================================================================
async function sincronizarNegocio(backendUrl, businessId, { profile, icp, salesHistoryAnalysis }) {
  const resp = await fetch(`${backendUrl.replace(/\/$/, "")}/api/business/sync`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ businessId, profile, icp, salesHistoryAnalysis }),
  });
  if (!resp.ok) throw new Error(`No se pudo sincronizar el negocio con el backend (${resp.status}).`);
  return await resp.json();
}

async function obtenerCola(backendUrl, businessId, status) {
  const qs = new URLSearchParams({ businessId, ...(status ? { status } : {}) });
  const resp = await fetch(`${backendUrl.replace(/\/$/, "")}/api/prospects/queue?${qs}`);
  if (!resp.ok) {
    const t = await resp.text().catch(() => "");
    throw new Error(`El backend respondió ${resp.status} al pedir la cola: ${t.slice(0, 200)}`);
  }
  return await resp.json();
}

async function dispararCicloManual(backendUrl, businessId, query) {
  const resp = await fetch(`${backendUrl.replace(/\/$/, "")}/api/prospects/search`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ businessId, query }),
  });
  if (!resp.ok) {
    const t = await resp.text().catch(() => "");
    throw new Error(`El backend respondió ${resp.status}: ${t.slice(0, 200)}`);
  }
  return await resp.json();
}

async function enviarFeedback(backendUrl, businessId, opportunityId, status, nota) {
  const resp = await fetch(`${backendUrl.replace(/\/$/, "")}/api/prospects/feedback`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ businessId, opportunityId, status, nota }),
  });
  if (!resp.ok) throw new Error(`No se pudo registrar el resultado (${resp.status}).`);
  return await resp.json();
}

async function obtenerMetricas(backendUrl, businessId) {
  const resp = await fetch(`${backendUrl.replace(/\/$/, "")}/api/prospects/metrics?businessId=${encodeURIComponent(businessId)}`);
  if (!resp.ok) throw new Error(`No se pudieron obtener las métricas (${resp.status}).`);
  return await resp.json();
}

function generarId() {
  try { return crypto.randomUUID(); } catch (e) { return `id-${Date.now()}-${Math.random().toString(36).slice(2)}`; }
}

// =================================================================
// ONBOARDING — solo tu negocio, sin pedir describir al cliente
// =================================================================
function Onboarding({ onCompletado, backendUrl }) {
  const [paso, setPaso] = useState(0);
  const [perfil, setPerfil] = useState({ nombre: "", web: "", queVendes: "", prioritarios: "", zona: "", objetivo: "Conseguir nuevos clientes" });
  const [generando, setGenerando] = useState(false);
  const [error, setError] = useState(null);

  function set(campo, valor) { setPerfil(p => ({ ...p, [campo]: valor })); }

  const pasos = [
    { titulo: "Tu negocio", valido: perfil.nombre && perfil.queVendes && perfil.zona, contenido: (
      <>
        <Label>Nombre del negocio</Label><TextInput value={perfil.nombre} onChange={v => set("nombre", v)} placeholder="Ej. Asesoría Martínez" />
        <div style={{ height: 14 }} /><Label>Web (opcional)</Label><TextInput value={perfil.web} onChange={v => set("web", v)} placeholder="https://..." />
        <div style={{ height: 14 }} /><Label>¿Qué vendes?</Label><TextInput value={perfil.queVendes} onChange={v => set("queVendes", v)} placeholder="Ej. asesoría financiera y seguros" />
        <div style={{ height: 14 }} /><Label>¿Qué es prioritario?</Label><TextInput value={perfil.prioritarios} onChange={v => set("prioritarios", v)} placeholder="Ej. seguros de hogar y ahorro" />
        <div style={{ height: 14 }} /><Label>¿En qué zona trabajas?</Label><TextInput value={perfil.zona} onChange={v => set("zona", v)} placeholder="Ej. Madrid capital" />
      </>) },
    { titulo: "Objetivo", valido: !!perfil.objetivo, contenido: (
      <>
        <Label>¿Cuál es tu objetivo?</Label>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {["Conseguir nuevos clientes", "Aumentar ventas", "Conseguir empresas", "Conseguir clientes de mayor valor", "Reactivar clientes"].map(o => (
            <Chip key={o} label={o} active={perfil.objetivo === o} onClick={() => set("objetivo", o)} />
          ))}
        </div>
        <p style={{ fontFamily: serif, color: COLORS.creamDim, fontSize: "0.82rem", marginTop: 16 }}>
          No hace falta que describas a tu cliente ideal — el siguiente paso analiza tu historial
          de ventas (o, si no tienes, tu propio negocio) para averiguarlo solo.
        </p>
      </>) },
  ];

  async function finalizar() {
    setGenerando(true); setError(null);
    try {
      const icp = await generarICP(backendUrl, perfil);
      let businessId = await cargar("business-id");
      if (!businessId) { businessId = generarId(); await guardar("business-id", businessId); }
      await guardar("business-profile", perfil);
      await guardar("icp", icp);
      onCompletado(perfil, icp, businessId);
    } catch (e) { setError(e.message || "No se pudo generar el ICP. Inténtalo de nuevo."); }
    finally { setGenerando(false); }
  }

  const actual = pasos[paso];
  return (
    <div style={{ maxWidth: 520, margin: "0 auto" }}>
      <div style={{ fontFamily: mono, fontSize: "0.7rem", color: COLORS.goldDim, letterSpacing: 1 }}>CONFIGURA TU NEGOCIO</div>
      <h1 style={{ fontFamily: serif, fontSize: "1.6rem", color: COLORS.cream, margin: "6px 0 4px 0" }}>{actual.titulo}</h1>
      <p style={{ fontFamily: mono, fontSize: "0.68rem", color: COLORS.creamDim, marginBottom: 20 }}>paso {paso + 1} de {pasos.length}</p>
      <Panel>{actual.contenido}</Panel>
      {error && <p style={{ fontFamily: serif, color: COLORS.red, fontSize: "0.85rem", marginTop: 12 }}>{error}</p>}
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 20 }}>
        {paso > 0 ? <GhostButton onClick={() => setPaso(p => p - 1)}>atrás</GhostButton> : <span />}
        {paso < pasos.length - 1 ? (
          <PrimaryButton disabled={!actual.valido} onClick={() => setPaso(p => p + 1)}>siguiente →</PrimaryButton>
        ) : (
          <PrimaryButton disabled={!actual.valido || generando} onClick={finalizar}>{generando ? "generando..." : "crear mi radar comercial"}</PrimaryButton>
        )}
      </div>
    </div>
  );
}

// =================================================================
// HISTORIAL DE VENTAS — PASO PREVIO OBLIGATORIO AL FLUJO
// =================================================================
function VistaHistorial({ perfil, icp, backendUrl, onICPActualizado, onIrABuscar }) {
  const [texto, setTexto] = useState("");
  const [analisis, setAnalisis] = useState(null);
  const [estado, setEstado] = useState("idle");
  const [errorMsg, setErrorMsg] = useState(null);
  const [aplicado, setAplicado] = useState(false);

  useEffect(() => { (async () => {
    const guardado = await cargar("historial-analisis");
    if (guardado) setAnalisis(guardado);
    const textoGuardado = await cargar("historial-texto");
    if (textoGuardado) setTexto(textoGuardado);
  })(); }, []);

  async function analizar() {
    if (!texto.trim()) return;
    setEstado("cargando"); setErrorMsg(null); setAplicado(false);
    try {
      const resultado = await analizarHistorialVentas(backendUrl, texto, perfil);
      setAnalisis(resultado); setEstado("listo");
      await guardar("historial-analisis", resultado);
      await guardar("historial-texto", texto);
    } catch (e) { setErrorMsg(e.message || "Error desconocido."); setEstado("error"); }
  }

  async function analizarSinHistorial() {
    setEstado("cargando"); setErrorMsg(null); setAplicado(false);
    try {
      const resultado = await inferirNichoSinHistorial(backendUrl, perfil);
      setAnalisis(resultado); setEstado("listo");
      await guardar("historial-analisis", resultado);
      await guardar("historial-texto", "");
    } catch (e) { setErrorMsg(e.message || "Error desconocido."); setEstado("error"); }
  }

  async function aplicarAlICP() {
    if (!analisis) return;
    const nuevoICP = {
      ...icp,
      targetSegments: analisis.targetSegmentsSugeridos?.length ? analisis.targetSegmentsSugeridos : icp.targetSegments,
      buyingSignals: analisis.buyingSignalsSugeridas?.length ? [...new Set([...icp.buyingSignals, ...analisis.buyingSignalsSugeridas])] : icp.buyingSignals,
    };
    await guardar("icp", nuevoICP);
    onICPActualizado(perfil, nuevoICP);
    setAplicado(true);
  }

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <SectionTitle>Historial de ventas → nicho de mercado</SectionTitle>
        <GhostButton onClick={onIrABuscar}>saltar, ir al radar →</GhostButton>
      </div>
      <p style={{ fontFamily: serif, color: COLORS.creamDim, fontSize: "0.88rem", marginTop: 8, marginBottom: 18 }}>
        Pega lo que tengas — no hace falta que esté completo ni ordenado, el sistema trabaja con
        lo que haya. Si todavía no tienes ninguna venta, también puedes saltarte este paso.
      </p>

      <Panel>
        <Label>Pega tu historial (lo que tengas, aunque sea poco)</Label>
        <textarea value={texto} onChange={e => setTexto(e.target.value)}
          placeholder={"Ej.\nCliente A, autónomo diseño, 450€, mensual\nCliente B, empresa reformas, 1200€, trimestral"}
          rows={8} style={{ width: "100%", fontFamily: mono, fontSize: "0.8rem", color: COLORS.cream, background: COLORS.bgPanelAlt,
            border: `1px solid ${COLORS.line}`, padding: "10px 12px", outline: "none", resize: "vertical", boxSizing: "border-box" }} />
        <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
          <PrimaryButton disabled={!texto.trim() || estado === "cargando"} onClick={analizar}>
            {estado === "cargando" ? "analizando..." : "analizar historial"}
          </PrimaryButton>
          <GhostButton onClick={analizarSinHistorial}>{estado === "cargando" ? "..." : "todavía no tengo historial — usar solo mi negocio"}</GhostButton>
        </div>
        {estado === "error" && (
          <div style={{ marginTop: 12, background: COLORS.bgPanelAlt, padding: "10px 12px", borderLeft: `3px solid ${COLORS.red}` }}>
            <p style={{ fontFamily: mono, color: COLORS.red, fontSize: "0.72rem", margin: 0 }}>{errorMsg}</p>
          </div>
        )}
      </Panel>

      {analisis && (
        <>
          <Panel style={{ marginTop: 16, borderLeft: `3px solid ${COLORS.gold}` }}>
            <Label>Nicho principal</Label>
            <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.95rem", margin: "0 0 14px 0" }}>{analisis.nichoPrincipal}</p>

            <Label>Por qué este nicho</Label>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 6 }}>
              <div><span style={{ fontFamily: mono, color: COLORS.creamDim, fontSize: "0.68rem" }}>evidencia en tu historial: </span><span style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.84rem" }}>{analisis.porQueEsteNicho?.evidenciaEnHistorial}</span></div>
              <div><span style={{ fontFamily: mono, color: COLORS.creamDim, fontSize: "0.68rem" }}>por qué mayor valor: </span><span style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.84rem" }}>{analisis.porQueEsteNicho?.porQueMayorValor}</span></div>
              <div><span style={{ fontFamily: mono, color: COLORS.creamDim, fontSize: "0.68rem" }}>qué buscar en nuevos prospectos: </span><span style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.84rem" }}>{analisis.porQueEsteNicho?.queCaracteristicasBuscar}</span></div>
              <div><span style={{ fontFamily: mono, color: COLORS.creamDim, fontSize: "0.68rem" }}>señales de compra ahora: </span><span style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.84rem" }}>{analisis.porQueEsteNicho?.señalesDeCompraAhora}</span></div>
            </div>

            {analisis.informacionFaltante && (
              <div style={{ marginTop: 12, background: COLORS.bgPanelAlt, padding: "8px 10px", borderLeft: `3px solid ${COLORS.blue}` }}>
                <p style={{ fontFamily: serif, color: COLORS.creamDim, fontSize: "0.78rem", margin: 0 }}>
                  <b style={{ color: COLORS.cream }}>Falta información: </b>{analisis.informacionFaltante}
                </p>
              </div>
            )}
          </Panel>

          <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 12 }}>
            <Panel style={{ borderLeft: `3px solid ${COLORS.green}` }}>
              <Label>Segmento más valioso</Label>
              <div style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.9rem" }}>{analisis.segmentoMasValioso?.nombre}</div>
              <p style={{ fontFamily: serif, color: COLORS.creamDim, fontSize: "0.82rem", marginTop: 6, marginBottom: 0 }}>{analisis.segmentoMasValioso?.porQue}</p>
            </Panel>
            <Panel style={{ borderLeft: `3px solid ${COLORS.blue}` }}>
              <Label>Segmento desaprovechado</Label>
              <div style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.9rem" }}>{analisis.segmentoDesaprovechado?.nombre}</div>
              <p style={{ fontFamily: serif, color: COLORS.creamDim, fontSize: "0.82rem", marginTop: 6, marginBottom: 0 }}>{analisis.segmentoDesaprovechado?.porQue}</p>
            </Panel>
          </div>

          <Panel style={{ marginTop: 12, background: COLORS.bgPanelAlt }}>
            <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.86rem", marginTop: 0 }}>
              Aplica este nicho a tu ICP para que la búsqueda de oportunidades lo use automáticamente.
            </p>
            <div style={{ display: "flex", gap: 8 }}>
              <PrimaryButton onClick={aplicarAlICP}>{aplicado ? "aplicado ✓" : "usar este nicho en el radar"}</PrimaryButton>
              {aplicado && <GhostButton onClick={onIrABuscar}>ir a buscar oportunidades →</GhostButton>}
            </div>
          </Panel>
        </>
      )}
    </div>
  );
}

// =================================================================
// RADAR COMERCIAL — autónomo, sin campo de texto para buscar
// =================================================================
function scoreColor(score) {
  if (score >= 75) return COLORS.green;
  if (score >= 50) return COLORS.gold;
  return COLORS.red;
}

function EstadoFuentes({ fuentesEstado }) {
  if (!fuentesEstado || !fuentesEstado.length) return null;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4, marginTop: 10 }}>
      {fuentesEstado.map((f, i) => (
        <div key={i} style={{ fontFamily: mono, fontSize: "0.68rem", color: f.error ? COLORS.red : f.conectado ? COLORS.green : COLORS.creamDim }}>
          {f.fuente}: {f.conectado ? (f.error ? `error — ${f.error}` : `${f.encontrados} resultados`) : "no conectado"}
        </div>
      ))}
    </div>
  );
}

function ModalPerfil({ p, onCerrar, onFeedback }) {
  if (!p) return null;
  const opciones = [
    ["CONTACTED", "Contactado"], ["NO_RESPONSE", "No respondió"], ["RESPONDED", "Respondió"],
    ["MEETING", "Reunión"], ["CUSTOMER", "Cliente"], ["NOT_A_GOOD_PROSPECT", "No era buen prospecto"], ["DISCARDED", "Descartar"],
  ];
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20, zIndex: 50 }} onClick={onCerrar}>
      <div style={{ maxWidth: 520, width: "100%", maxHeight: "85vh", overflowY: "auto", background: COLORS.bgPanel, border: `1px solid ${COLORS.line}`, padding: 24 }} onClick={e => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontFamily: serif, fontSize: "1.25rem", color: COLORS.cream }}>{p.nombre || "Nombre no disponible"}</div>
            <div style={{ fontFamily: mono, fontSize: "0.75rem", color: COLORS.creamDim, marginTop: 2 }}>
              {p.cargo ? `${p.cargo} · ` : ""}{p.empresa || "Empresa no disponible"} · {p.ubicacion || "Ubicación no disponible"}
            </div>
            <Badge color={COLORS.blue}>{p.status}</Badge>
          </div>
          <div style={{ fontFamily: mono, fontSize: "1.4rem", color: scoreColor(p.leadScoreFinal) }}>{p.leadScoreFinal}</div>
        </div>

        <Label style={{ marginTop: 20 }}>Por qué encaja</Label>
        <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.88rem" }}>{p.porQueEncaja}</p>
        <Label>Por qué ahora</Label>
        <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.88rem" }}>{p.porQueAhora}</p>
        <Label>Señal detectada</Label>
        <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.88rem" }}>{p.señalDetectada}</p>

        {p.actualidadReciente && (
          <>
            <Label>Actualidad reciente</Label>
            <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.88rem" }}>
              {p.actualidadReciente}
              {p.fuenteUrlActualidad && <> — <a href={p.fuenteUrlActualidad} target="_blank" rel="noreferrer" style={{ color: COLORS.blue }}>ver fuente</a></>}
            </p>
          </>
        )}

        <Label>Desglose del score</Label>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 16 }}>
          {[["Fit", p.scoreFit], ["Intención", p.scoreIntent], ["Timing", p.scoreTiming], ["Contactabilidad", p.scoreContactability], ["Frescura", p.scoreFreshness], ["Calidad del dato", p.scoreDataQuality]].map(([k, v]) => (
            <div key={k} style={{ background: COLORS.bgPanelAlt, padding: "8px 10px" }}>
              <div style={{ fontFamily: mono, fontSize: "0.62rem", color: COLORS.creamDim }}>{k}</div>
              <div style={{ fontFamily: mono, fontSize: "0.9rem", color: COLORS.gold }}>{v}</div>
            </div>
          ))}
        </div>

        <Label>Acción recomendada</Label>
        <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.88rem" }}>{p.accionRecomendada}</p>

        {p.mensajeSugerido && (
          <>
            <Label>Mensaje sugerido</Label>
            <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.85rem", fontStyle: "italic", background: COLORS.bgPanelAlt, padding: "10px 12px" }}>"{p.mensajeSugerido}"</p>
          </>
        )}

        <Label style={{ marginTop: 16 }}>Trazabilidad</Label>
        <p style={{ fontFamily: mono, color: COLORS.creamDim, fontSize: "0.72rem" }}>
          fuente: {p.fuente} · descubierto: {p.descubiertoEn ? new Date(p.descubiertoEn).toLocaleString("es-ES") : "no disponible"}
          {p.fuenteUrl ? <> · <a href={p.fuenteUrl} target="_blank" rel="noreferrer" style={{ color: COLORS.blue }}>ver fuente original</a></> : null}
        </p>

        <Label style={{ marginTop: 16 }}>Registrar resultado</Label>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {opciones.map(([v, l]) => <Chip key={v} label={l} active={p.status === v} onClick={() => onFeedback(v)} />)}
        </div>

        <div style={{ marginTop: 20, textAlign: "right" }}><GhostButton onClick={onCerrar}>cerrar</GhostButton></div>
      </div>
    </div>
  );
}

function TarjetaProspecto({ p, onFeedback, onVer }) {
  const c = scoreColor(p.leadScoreFinal);
  return (
    <Panel style={{ display: "flex", gap: 16, alignItems: "flex-start" }}>
      <div style={{ width: 58, flexShrink: 0, border: `1px solid ${c}`, padding: "10px 4px", textAlign: "center" }}>
        <div style={{ fontFamily: serif, fontSize: "1.4rem", color: c, lineHeight: 1 }}>{p.leadScoreFinal}</div>
        <div style={{ fontFamily: mono, fontSize: "0.52rem", color: COLORS.creamDim, letterSpacing: 0.5, textTransform: "uppercase", marginTop: 4 }}>índice</div>
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", flexWrap: "wrap", gap: 6 }}>
          <div style={{ fontFamily: serif, fontSize: "1.05rem", color: COLORS.cream }}>{p.nombre || "Nombre no disponible"}</div>
          <span style={{ fontFamily: mono, fontSize: "0.62rem", color: p.prioridad === "alta" ? COLORS.green : p.prioridad === "media" ? COLORS.gold : COLORS.creamDim, letterSpacing: 0.5, textTransform: "uppercase" }}>
            prioridad {p.prioridad}
          </span>
        </div>
        <div style={{ fontFamily: mono, fontSize: "0.72rem", color: COLORS.creamDim, marginTop: 2 }}>
          {p.cargo ? `${p.cargo} · ` : ""}{p.empresa || "Empresa no disponible"} · {p.ubicacion || "Ubicación no disponible"}
        </div>

        <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.86rem", marginTop: 12, marginBottom: 8, lineHeight: 1.5 }}>{p.porQueEncaja}</p>

        <div style={{ borderLeft: `2px solid ${COLORS.line}`, paddingLeft: 10, display: "flex", flexDirection: "column", gap: 3 }}>
          <div style={{ fontFamily: mono, fontSize: "0.68rem", color: COLORS.gold }}><b>por qué ahora —</b> {p.porQueAhora}</div>
          <div style={{ fontFamily: mono, fontSize: "0.68rem", color: COLORS.creamDim }}><b>señal —</b> {p.señalDetectada}</div>
          {p.actualidadReciente && (
            <div style={{ fontFamily: mono, fontSize: "0.68rem", color: COLORS.blue }}><b>actualidad —</b> {p.actualidadReciente}</div>
          )}
        </div>

        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 12 }}>
          <Badge color={COLORS.blue}>{p.canalContacto}</Badge>
          <Badge color={COLORS.goldDim}>{p.fuente}</Badge>
        </div>

        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 14 }}>
          <GhostButton onClick={() => onFeedback("CONTACTED")}>contactar</GhostButton>
          <GhostButton onClick={onVer}>ver oportunidad</GhostButton>
          <GhostButton onClick={() => onFeedback("DISCARDED")} style={{ color: COLORS.red, borderColor: COLORS.red }}>descartar</GhostButton>
        </div>
      </div>
    </Panel>
  );
}

function tiempoDesde(fechaISO) {
  if (!fechaISO) return "todavía sin actualizar";
  const minutos = Math.round((Date.now() - new Date(fechaISO).getTime()) / 60000);
  if (minutos < 1) return "hace un momento";
  if (minutos < 60) return `hace ${minutos} min`;
  const horas = Math.round(minutos / 60);
  if (horas < 24) return `hace ${horas} h`;
  return `hace ${Math.round(horas / 24)} días`;
}

function Dashboard({ perfil, icp, backendUrl, businessId, analisisHistorial }) {
  const [cola, setCola] = useState([]);
  const [meta, setMeta] = useState({ pendientes: 0, ultimaActualizacion: null, cicloAutomaticoEjecutado: false, resultadoCiclo: null });
  const [estado, setEstado] = useState("idle"); // idle | cargando | error | listo | sin-backend
  const [errorMsg, setErrorMsg] = useState(null);
  const [seleccionado, setSeleccionado] = useState(null);
  const [buscandoMas, setBuscandoMas] = useState(false);
  const [metricas, setMetricas] = useState(null);
  const [mostrarMetricas, setMostrarMetricas] = useState(false);

  const ESTADOS_PENDIENTES = ["NEW", "PRIORITIZED", "READY_TO_CONTACT"];

  async function cargarRadar() {
    if (!backendUrl) { setEstado("sin-backend"); return; }
    setEstado("cargando"); setErrorMsg(null);
    try {
      await sincronizarNegocio(backendUrl, businessId, { profile: perfil, icp, salesHistoryAnalysis: analisisHistorial });
      const r = await obtenerCola(backendUrl, businessId);
      const pendientes = (r.oportunidades || []).filter(o => ESTADOS_PENDIENTES.includes(o.status));
      setCola(pendientes);
      setMeta({ pendientes: r.pendientes, ultimaActualizacion: r.ultimaActualizacion, cicloAutomaticoEjecutado: r.cicloAutomaticoEjecutado, resultadoCiclo: r.resultadoCiclo });
      setEstado("listo");
    } catch (e) {
      setErrorMsg(e.message || "Error desconocido."); setEstado("error");
    }
  }

  useEffect(() => { cargarRadar(); /* eslint-disable-next-line */ }, [backendUrl, businessId]);

  async function marcarFeedback(opportunityId, status) {
    try {
      await enviarFeedback(backendUrl, businessId, opportunityId, status);
      setCola(prev => prev.filter(o => o.id !== opportunityId)); // sale de "pendientes" al tener un resultado
      if (seleccionado?.id === opportunityId) setSeleccionado(null);
    } catch (e) {
      setErrorMsg(e.message || "No se pudo registrar el resultado.");
    }
  }

  // buscarMasAhora — dispara otro ciclo SIN que el usuario indique ningún criterio.
  // El sistema decide qué buscar por sí solo, a partir del ICP y el historial ya guardados.
  async function buscarMasAhora() {
    setBuscandoMas(true); setErrorMsg(null);
    try {
      await dispararCicloManual(backendUrl, businessId, "");
      await cargarRadar();
    } catch (e) {
      setErrorMsg(e.message || "Error al buscar más oportunidades.");
    } finally { setBuscandoMas(false); }
  }

  async function verMetricas() {
    setMostrarMetricas(v => !v);
    if (!metricas && backendUrl) {
      try { setMetricas(await obtenerMetricas(backendUrl, businessId)); } catch (e) {}
    }
  }

  const altaPrioridad = cola.filter(p => p.prioridad === "alta").length;
  const mediaPrioridad = cola.filter(p => p.prioridad === "media").length;
  const ordenada = [...cola].sort((a, b) => b.leadScoreFinal - a.leadScoreFinal);

  return (
    <div>
      <div style={{ fontFamily: mono, fontSize: "0.72rem", color: COLORS.creamDim }}>Buenos días, {perfil.nombre}</div>
      <SectionTitle style={{ marginTop: 6 }}>Radar comercial</SectionTitle>

      {analisisHistorial && (
        <Panel style={{ marginTop: 10, marginBottom: 16, borderLeft: `3px solid ${COLORS.gold}` }}>
          <Label>Nicho recomendado</Label>
          <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.9rem", margin: 0 }}>{analisisHistorial.nichoPrincipal}</p>
        </Panel>
      )}

      {estado === "sin-backend" && (
        <Panel style={{ borderLeft: `3px solid ${COLORS.red}` }}>
          <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.9rem", marginTop: 0 }}>Para que el radar funcione necesitas conectar una fuente de datos.</p>
          <p style={{ fontFamily: serif, color: COLORS.creamDim, fontSize: "0.82rem" }}>No hay ningún backend configurado — ve a "Fuentes" y pega la URL de tu backend desplegado.</p>
        </Panel>
      )}

      {estado === "error" && (
        <Panel style={{ borderLeft: `3px solid ${COLORS.red}` }}>
          <p style={{ fontFamily: mono, color: COLORS.red, fontSize: "0.75rem", margin: 0 }}>{errorMsg}</p>
          <div style={{ marginTop: 10 }}><GhostButton onClick={cargarRadar}>reintentar</GhostButton></div>
        </Panel>
      )}

      {estado === "cargando" && (
        <Panel style={{ textAlign: "center" }}><p style={{ fontFamily: mono, color: COLORS.creamDim, fontSize: "0.8rem", margin: 0 }}>revisando tu radar...</p></Panel>
      )}

      {estado === "listo" && (
        <>
          <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.95rem", marginBottom: 4 }}>
            {meta.cicloAutomaticoEjecutado && meta.resultadoCiclo?.nuevas > 0
              ? `Tu sistema ha encontrado ${meta.resultadoCiclo.nuevas} nuevas oportunidades.`
              : cola.length > 0 ? `Tienes ${cola.length} oportunidades esperando.` : "No hay oportunidades pendientes ahora mismo."}
          </p>
          <p style={{ fontFamily: mono, color: COLORS.creamDim, fontSize: "0.68rem", marginBottom: 16 }}>Última actualización: {tiempoDesde(meta.ultimaActualizacion)}</p>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8, marginBottom: 16 }}>
            <Panel style={{ textAlign: "center", padding: "14px 8px" }}>
              <div style={{ fontFamily: mono, fontSize: "1.4rem", color: COLORS.green }}>🔥 {altaPrioridad}</div>
              <div style={{ fontFamily: mono, fontSize: "0.62rem", color: COLORS.creamDim }}>alta prioridad</div>
            </Panel>
            <Panel style={{ textAlign: "center", padding: "14px 8px" }}>
              <div style={{ fontFamily: mono, fontSize: "1.4rem", color: COLORS.gold }}>🟠 {mediaPrioridad}</div>
              <div style={{ fontFamily: mono, fontSize: "0.62rem", color: COLORS.creamDim }}>para revisar</div>
            </Panel>
            <Panel style={{ textAlign: "center", padding: "14px 8px" }}>
              <div style={{ fontFamily: mono, fontSize: "1.4rem", color: COLORS.cream }}>{cola.length}</div>
              <div style={{ fontFamily: mono, fontSize: "0.62rem", color: COLORS.creamDim }}>total en cola</div>
            </Panel>
          </div>

          {meta.resultadoCiclo?.fuentesEstado && <EstadoFuentes fuentesEstado={meta.resultadoCiclo.fuentesEstado} />}
          {meta.resultadoCiclo?.mensaje && (
            <Panel style={{ marginTop: 10, borderLeft: `3px solid ${COLORS.blue}` }}>
              <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.85rem", margin: 0 }}>{meta.resultadoCiclo.mensaje}</p>
            </Panel>
          )}

          <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 16 }}>
            {ordenada.map((p) => (
              <TarjetaProspecto key={p.id} p={p} onFeedback={(status) => marcarFeedback(p.id, status)} onVer={() => setSeleccionado(p)} />
            ))}
          </div>

          <div style={{ marginTop: 24, borderTop: `1px solid ${COLORS.line}`, paddingTop: 16, textAlign: "center" }}>
            <GhostButton onClick={buscarMasAhora}>{buscandoMas ? "buscando..." : "buscar más oportunidades ahora"}</GhostButton>
            <p style={{ fontFamily: mono, fontSize: "0.62rem", color: COLORS.creamDim, marginTop: 8 }}>
              el sistema decide qué buscar solo, a partir de tu nicho — no hace falta que le digas nada
            </p>
          </div>

          <div style={{ marginTop: 16 }}>
            <GhostButton onClick={verMetricas}>{mostrarMetricas ? "ocultar métricas" : "ver métricas del radar"}</GhostButton>
            {mostrarMetricas && metricas && (
              <Panel style={{ marginTop: 10 }}>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, fontFamily: mono, fontSize: "0.72rem", color: COLORS.creamDim }}>
                  <div>descubiertas: <span style={{ color: COLORS.cream }}>{metricas.totalDescubiertas}</span></div>
                  <div>contactadas: <span style={{ color: COLORS.cream }}>{metricas.contactadas}</span></div>
                  <div>reuniones: <span style={{ color: COLORS.cream }}>{metricas.reuniones}</span></div>
                  <div>clientes: <span style={{ color: COLORS.cream }}>{metricas.clientes}</span></div>
                  <div>tasa de conversión: <span style={{ color: COLORS.gold }}>{metricas.tasaConversion !== null ? `${metricas.tasaConversion}%` : "sin datos aún"}</span></div>
                  <div>último ciclo: <span style={{ color: COLORS.cream }}>{tiempoDesde(metricas.ultimoCiclo)}</span></div>
                </div>
              </Panel>
            )}
          </div>
        </>
      )}

      {seleccionado && (
        <ModalPerfil p={seleccionado} onCerrar={() => setSeleccionado(null)} onFeedback={(status) => marcarFeedback(seleccionado.id, status)} />
      )}
    </div>
  );
}

// =================================================================
// FUENTES — configuración del backend + estado real de cada fuente
// =================================================================
function VistaFuentes({ backendUrl, onGuardarUrl }) {
  const [url, setUrl] = useState(backendUrl || "");
  const [estadoFuentes, setEstadoFuentes] = useState(null);
  const [comprobando, setComprobando] = useState(false);
  const [errorComprobacion, setErrorComprobacion] = useState(null);

  async function comprobar() {
    if (!url) return;
    setComprobando(true); setErrorComprobacion(null);
    try {
      const resp = await fetch(`${url.replace(/\/$/, "")}/api/sources/status`);
      if (!resp.ok) throw new Error(`El backend respondió ${resp.status}`);
      const data = await resp.json();
      setEstadoFuentes(data);
    } catch (e) {
      setErrorComprobacion(e.message || "No se pudo conectar con el backend.");
      setEstadoFuentes(null);
    } finally { setComprobando(false); }
  }

  async function guardarUrl() {
    await guardar("backend-url", url);
    onGuardarUrl(url);
    comprobar();
  }

  return (
    <div>
      <SectionTitle>Fuentes de datos</SectionTitle>
      <p style={{ fontFamily: serif, color: COLORS.creamDim, fontSize: "0.88rem", marginTop: 8, marginBottom: 18 }}>
        La búsqueda real no ocurre en este navegador — ocurre en tu backend, donde viven las claves
        de Apollo, People Data Labs y Anthropic de forma segura. Aquí solo indicas dónde está desplegado.
      </p>

      <Panel>
        <Label>URL de tu backend</Label>
        <TextInput value={url} onChange={setUrl} placeholder="https://tu-backend.onrender.com" />
        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
          <PrimaryButton onClick={guardarUrl}>guardar y comprobar</PrimaryButton>
          {backendUrl && <GhostButton onClick={comprobar}>{comprobando ? "comprobando..." : "volver a comprobar"}</GhostButton>}
        </div>
      </Panel>

      {errorComprobacion && (
        <Panel style={{ marginTop: 12, borderLeft: `3px solid ${COLORS.red}` }}>
          <p style={{ fontFamily: mono, color: COLORS.red, fontSize: "0.75rem", margin: 0 }}>{errorComprobacion}</p>
        </Panel>
      )}

      {estadoFuentes && (
        <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 16 }}>
          {estadoFuentes.map((f) => (
            <Panel key={f.fuente} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.92rem" }}>{f.fuente}</div>
              <Badge color={f.conectado ? COLORS.green : COLORS.red}>{f.conectado ? "conectado ✓" : "no conectado"}</Badge>
            </Panel>
          ))}
        </div>
      )}

      <Panel style={{ marginTop: 20, background: COLORS.bgPanelAlt }}>
        <p style={{ fontFamily: serif, color: COLORS.creamDim, fontSize: "0.82rem", margin: 0 }}>
          ¿Todavía no tienes el backend desplegado? Está en el archivo <code style={{ color: COLORS.gold }}>backend/</code> que
          te entregué junto a este artefacto, con instrucciones en su README para desplegarlo (Render, Railway, etc.)
          y las variables de entorno exactas que necesitas rellenar.
        </p>
      </Panel>
    </div>
  );
}

// =================================================================
// CONFIGURACIÓN Y PRIVACIDAD
// =================================================================
function VistaConfiguracion({ perfil, icp, onActualizar, backendUrl }) {
  const [local, setLocal] = useState(perfil);
  const [regenerando, setRegenerando] = useState(false);
  function set(campo, valor) { setLocal(p => ({ ...p, [campo]: valor })); }
  async function guardarCambios() { await guardar("business-profile", local); onActualizar(local, icp); }
  async function regenerarICP() {
    setRegenerando(true);
    try {
      const nuevoICP = await generarICP(backendUrl, local);
      await guardar("business-profile", local); await guardar("icp", nuevoICP);
      onActualizar(local, nuevoICP);
    } finally { setRegenerando(false); }
  }
  return (
    <div>
      <SectionTitle>Mi negocio</SectionTitle>
      <Panel style={{ marginTop: 14 }}>
        <Label>Nombre</Label><TextInput value={local.nombre} onChange={v => set("nombre", v)} />
        <div style={{ height: 12 }} /><Label>Qué vendes</Label><TextInput value={local.queVendes} onChange={v => set("queVendes", v)} />
        <div style={{ height: 12 }} /><Label>Zona</Label><TextInput value={local.zona} onChange={v => set("zona", v)} />
        <div style={{ height: 12 }} /><Label>Qué es prioritario</Label><TextInput value={local.prioritarios} onChange={v => set("prioritarios", v)} />
        <div style={{ height: 16 }} />
        <div style={{ display: "flex", gap: 8 }}>
          <PrimaryButton onClick={guardarCambios}>guardar cambios</PrimaryButton>
          <GhostButton onClick={regenerarICP}>{regenerando ? "regenerando..." : "regenerar cliente ideal"}</GhostButton>
        </div>
      </Panel>
      <SectionTitle style={{ marginTop: 24 }}>Cliente ideal actual (ICP)</SectionTitle>
      <Panel style={{ marginTop: 12 }}>
        <Label>Segmentos objetivo</Label>
        {icp.targetSegments.map((s, i) => (
          <div key={i} style={{ marginBottom: 8 }}>
            <div style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.86rem" }}>{s.nombre}</div>
            <div style={{ fontFamily: serif, color: COLORS.creamDim, fontSize: "0.78rem" }}>{s.descripcion}</div>
          </div>
        ))}
        <Label style={{ marginTop: 12 }}>Señales de compra</Label>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{icp.buyingSignals.map((s, i) => <Badge key={i}>{s}</Badge>)}</div>
        <Label style={{ marginTop: 12 }}>Exclusiones</Label>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>{icp.exclusions.map((s, i) => <Badge key={i} color={COLORS.red}>{s}</Badge>)}</div>
      </Panel>
    </div>
  );
}

function VistaPrivacidad() {
  return (
    <div>
      <SectionTitle>Privacidad y uso de datos</SectionTitle>
      <Panel style={{ marginTop: 14 }}>
        <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.88rem", marginTop: 0 }}>Este sistema está diseñado para utilizar únicamente:</p>
        <ul style={{ paddingLeft: 20, margin: 0 }}>
          {["Datos obtenidos de fuentes autorizadas o licenciadas", "Información pública cuando su utilización sea legítima",
            "Canales profesionales apropiados para el contacto comercial", "Datos cuyo uso para prospección esté permitido por la fuente de origen"].map((t, i) => (
            <li key={i} style={{ fontFamily: serif, color: COLORS.creamDim, fontSize: "0.85rem", marginBottom: 6 }}>{t}</li>
          ))}
        </ul>
      </Panel>
      <Panel style={{ marginTop: 12, borderLeft: `3px solid ${COLORS.red}` }}>
        <p style={{ fontFamily: serif, color: COLORS.cream, fontSize: "0.85rem", margin: 0 }}>
          Las posibilidades de contacto y las obligaciones legales dependen del país, el tipo de dato
          y el contexto comercial. Verifica la base jurídica y las condiciones de cada fuente antes de
          contactar a un prospecto. Que un dato incluya un email o teléfono no implica por sí solo que
          su uso para prospección sea legal.
        </p>
      </Panel>
      <Panel style={{ marginTop: 12 }}>
        <p style={{ fontFamily: serif, color: COLORS.creamDim, fontSize: "0.85rem", margin: 0 }}>
          El sistema no realiza scraping agresivo ni automatiza plataformas que lo prohíban expresamente
          (ej. LinkedIn). Cada prospecto conserva su fuente, fecha de obtención y estado de contacto.
        </p>
      </Panel>
    </div>
  );
}

// =================================================================
// APP PRINCIPAL
// =================================================================
const TABS = [
  { id: "historial", label: "Historial" },
  { id: "radar", label: "Radar comercial" },
  { id: "fuentes", label: "Fuentes" },
  { id: "config", label: "Mi negocio" },
  { id: "privacidad", label: "Privacidad" },
];

export default function RadarComercial() {
  const [cargando, setCargando] = useState(true);
  const [perfil, setPerfil] = useState(null);
  const [icp, setIcp] = useState(null);
  const [businessId, setBusinessId] = useState(null);
  const [tab, setTab] = useState("historial");
  const [backendUrl, setBackendUrl] = useState(null);
  const [analisisHistorial, setAnalisisHistorial] = useState(null);

  useEffect(() => { (async () => {
    const p = await cargar("business-profile"); const i = await cargar("icp"); const bid = await cargar("business-id");
    if (p && i && bid) { setPerfil(p); setIcp(i); setBusinessId(bid); }
    const url = await cargar("backend-url"); setBackendUrl(url || BACKEND_URL_PREDETERMINADA);
    const ah = await cargar("historial-analisis"); if (ah) setAnalisisHistorial(ah);
    setCargando(false);
  })(); }, []);

  function onOnboardingCompletado(p, i, bid) {
    setPerfil(p); setIcp(i);
    if (bid) setBusinessId(bid);
  }
  function onICPActualizado(p, i) { setPerfil(p); setIcp(i); cargar("historial-analisis").then(setAnalisisHistorial); }

  if (cargando) return <div style={{ background: COLORS.bg, minHeight: "100vh" }} />;

  return (
    <div style={{ background: COLORS.bg, minHeight: "100vh", padding: "32px 20px 60px", fontFamily: serif }}>
      <div style={{ maxWidth: 640, margin: "0 auto" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 34, height: 34, border: `1px solid ${COLORS.gold}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <span style={{ fontFamily: serif, fontSize: "0.95rem", color: COLORS.gold, letterSpacing: 0.5 }}>RC</span>
          </div>
          <div>
            <div style={{ fontFamily: serif, fontSize: "1.05rem", color: COLORS.cream, letterSpacing: 0.4 }}>Radar Comercial</div>
            <div style={{ fontFamily: mono, fontSize: "0.6rem", color: COLORS.creamDim, letterSpacing: 1.4, textTransform: "uppercase", marginTop: 1 }}>Inteligencia de prospección</div>
          </div>
        </div>
        <div style={{ height: 1, background: `linear-gradient(to right, ${COLORS.gold}, transparent)`, marginTop: 16 }} />

        {!perfil || !icp || !businessId ? (
          <div style={{ marginTop: 28 }}><Onboarding onCompletado={onOnboardingCompletado} backendUrl={backendUrl} /></div>
        ) : (
          <>
            <div style={{ display: "flex", gap: 4, marginTop: 24, borderBottom: `1px solid ${COLORS.line}`, overflowX: "auto" }}>
              {TABS.map(t => (
                <button key={t.id} onClick={() => setTab(t.id)} style={{
                  fontFamily: mono, fontSize: "0.72rem", whiteSpace: "nowrap", background: "transparent", border: "none", cursor: "pointer", padding: "10px 14px", letterSpacing: 0.2,
                  color: tab === t.id ? COLORS.gold : COLORS.creamDim, borderBottom: tab === t.id ? `2px solid ${COLORS.gold}` : "2px solid transparent",
                }}>{t.label}</button>
              ))}
            </div>
            <div style={{ marginTop: 22 }}>
              {tab === "historial" && <VistaHistorial perfil={perfil} icp={icp} backendUrl={backendUrl} onICPActualizado={onICPActualizado} onIrABuscar={() => setTab("radar")} />}
              {tab === "radar" && <Dashboard perfil={perfil} icp={icp} backendUrl={backendUrl} businessId={businessId} analisisHistorial={analisisHistorial} />}
              {tab === "fuentes" && <VistaFuentes backendUrl={backendUrl} onGuardarUrl={setBackendUrl} />}
              {tab === "config" && <VistaConfiguracion perfil={perfil} icp={icp} onActualizar={onOnboardingCompletado} backendUrl={backendUrl} />}
              {tab === "privacidad" && <VistaPrivacidad />}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
