import React from "react";
import ReactDOM from "react-dom/client";
import RadarComercial from "./RadarComercial.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <RadarComercial />
  </React.StrictMode>
);
